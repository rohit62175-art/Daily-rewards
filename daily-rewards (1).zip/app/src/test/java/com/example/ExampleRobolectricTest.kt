package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.DailyRewardsRepository
import com.example.model.PayoutMethod
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `verify app name resource`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Daily Rewards", appName)
    }

    @Test
    fun `verify repository initial state and streak checkin`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = DailyRewardsRepository(context)

        val user = repository.currentUser.value
        assertNotNull(user)
        assertTrue(user!!.totalCoins >= 100)

        // Claim check in
        val claimResult = repository.claimDailyCheckIn()
        assertTrue(claimResult.isSuccess)
    }

    @Test
    fun `verify withdrawal threshold validation`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = DailyRewardsRepository(context)

        // Try to withdraw below minimum (10 coins when minimum is 500)
        val failResult = repository.requestWithdrawal(PayoutMethod.UPI, "test@upi", 10)
        assertTrue(failResult.isFailure)
    }
}
