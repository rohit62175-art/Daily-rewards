package com.example.model

data class User(
    val id: String,
    val name: String,
    val email: String,
    val referralCode: String,
    val referredBy: String? = null,
    val joinedTimestamp: Long = System.currentTimeMillis(),
    val totalCoins: Long = 100, // Welcome bonus of 100 coins!
    val totalWithdrawnCoins: Long = 0,
    val successfulReferralsCount: Int = 0,
    val isAdmin: Boolean = false,
    val isBanned: Boolean = false,
    val lastCheckInDate: String = "",
    val checkInStreak: Int = 0
)
