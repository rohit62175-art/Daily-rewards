package com.example.model

enum class TransactionType {
    EARNED,
    WITHDRAWN
}

data class CoinTransaction(
    val id: String,
    val title: String,
    val titleHi: String,
    val description: String,
    val amount: Long,
    val type: TransactionType,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "SUCCESS" // SUCCESS, PENDING, REJECTED
)
