package com.example.model

enum class TaskType {
    DAILY_CHECKIN,
    WATCH_AD,
    SPIN_WHEEL,
    SCRATCH_CARD,
    MATH_QUIZ,
    SURVEY,
    SOCIAL,
    INVITE
}

data class RewardTask(
    val id: String,
    val title: String,
    val titleHi: String,
    val description: String,
    val descriptionHi: String,
    val rewardCoins: Long,
    val type: TaskType,
    val isCompletedToday: Boolean = false,
    val timesCompletedToday: Int = 0,
    val maxTimesPerDay: Int = 1,
    val cooldownMinutes: Int = 0,
    val lastCompletedTime: Long = 0L,
    val iconName: String = "stars",
    val isActive: Boolean = true
)
