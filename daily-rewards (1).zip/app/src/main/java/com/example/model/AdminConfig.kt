package com.example.model

data class AdminConfig(
    val minimumWithdrawalCoins: Long = 500, // 500 coins = ₹50
    val coinsPerRupee: Long = 10,           // 10 coins = ₹1 (100 coins = ₹10)
    val referralBonusCoins: Long = 250,     // Referrer gets 250 coins
    val refereeBonusCoins: Long = 100,      // Referred friend gets 100 coins
    val isWithdrawalsEnabled: Boolean = true,
    val adminPasscode: String = "7788",
    val noticeBoardText: String = "🎉 Instant payouts via UPI & Paytm! Complete daily check-in and tasks to earn daily."
)
