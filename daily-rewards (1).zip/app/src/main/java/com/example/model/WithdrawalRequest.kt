package com.example.model

enum class PayoutMethod(val title: String, val iconRes: String, val hint: String) {
    UPI("UPI Transfer", "upi", "Enter UPI ID (e.g. mobile@upi, name@okaxis)"),
    PAYTM("Paytm Wallet", "paytm", "Enter 10-digit Paytm Mobile Number"),
    GOOGLE_PLAY("Google Play Code", "play", "Enter Email address to receive gift code"),
    AMAZON("Amazon Pay Voucher", "amazon", "Enter Email address or Mobile number")
}

enum class WithdrawalStatus {
    PENDING,
    APPROVED,
    REJECTED
}

data class WithdrawalRequest(
    val id: String,
    val userId: String,
    val userName: String,
    val method: PayoutMethod,
    val payoutDetails: String,
    val coinsAmount: Long,
    val inrAmount: Double,
    val status: WithdrawalStatus = WithdrawalStatus.PENDING,
    val requestTimestamp: Long = System.currentTimeMillis(),
    val processedTimestamp: Long? = null,
    val adminNote: String? = null,
    val utrOrRefNumber: String? = null
)
