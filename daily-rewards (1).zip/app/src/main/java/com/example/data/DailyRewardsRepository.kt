package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AdminConfig
import com.example.model.CoinTransaction
import com.example.model.PayoutMethod
import com.example.model.RewardTask
import com.example.model.TaskType
import com.example.model.TransactionType
import com.example.model.User
import com.example.model.WithdrawalRequest
import com.example.model.WithdrawalStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class DailyRewardsRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("daily_rewards_prefs", Context.MODE_PRIVATE)

    // Current logged-in user
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    // Transactions list
    private val _transactions = MutableStateFlow<List<CoinTransaction>>(emptyList())
    val transactions: StateFlow<List<CoinTransaction>> = _transactions.asStateFlow()

    // Tasks list
    private val _tasks = MutableStateFlow<List<RewardTask>>(emptyList())
    val tasks: StateFlow<List<RewardTask>> = _tasks.asStateFlow()

    // Withdrawal requests
    private val _withdrawals = MutableStateFlow<List<WithdrawalRequest>>(emptyList())
    val withdrawals: StateFlow<List<WithdrawalRequest>> = _withdrawals.asStateFlow()

    // Admin configuration
    private val _adminConfig = MutableStateFlow(AdminConfig())
    val adminConfig: StateFlow<AdminConfig> = _adminConfig.asStateFlow()

    // Registered users (for admin management)
    private val _allUsers = MutableStateFlow<List<User>>(emptyList())
    val allUsers: StateFlow<List<User>> = _allUsers.asStateFlow()

    // Language setting: "en" or "hi"
    private val _language = MutableStateFlow(prefs.getString("app_lang", "en") ?: "en")
    val language: StateFlow<String> = _language.asStateFlow()

    init {
        loadData()
    }

    fun setLanguage(lang: String) {
        _language.value = lang
        prefs.edit().putString("app_lang", lang).apply()
    }

    private fun loadData() {
        val userJson = prefs.getString("current_user", null)
        if (userJson != null) {
            _currentUser.value = parseUser(userJson)
        } else {
            // Default demo account ready so user can immediately experience the app
            val defaultUser = User(
                id = "usr_rohit_01",
                name = "Rohit Kumar",
                email = "rohit62175@gmail.com",
                referralCode = "REWARD77K",
                totalCoins = 380,
                checkInStreak = 2,
                lastCheckInDate = getYesterdayDateString()
            )
            _currentUser.value = defaultUser
            saveUser(defaultUser)
        }

        // Initialize Tasks
        initTasks()

        // Load or create transactions
        loadTransactions()

        // Load or create withdrawals
        loadWithdrawals()
    }

    private fun initTasks() {
        val defaultTasks = listOf(
            RewardTask(
                id = "task_checkin",
                title = "Daily Check-in",
                titleHi = "दैनिक हाजिरी (चेक-इन)",
                description = "Claim your daily streak coin bonus",
                descriptionHi = "लगातार लॉगिन बोनस प्राप्त करें",
                rewardCoins = 25,
                type = TaskType.DAILY_CHECKIN,
                iconName = "calendar",
                isCompletedToday = false
            ),
            RewardTask(
                id = "task_rewarded_ad",
                title = "Watch Rewarded Video",
                titleHi = "रिवॉर्डेड वीडियो देखें",
                description = "Watch a short sponsored video & earn instantly",
                descriptionHi = "छोटा विज्ञापन वीडियो देखकर तुरंत सिक्के पाएँ",
                rewardCoins = 30,
                type = TaskType.WATCH_AD,
                iconName = "play_circle",
                maxTimesPerDay = 10,
                cooldownMinutes = 2
            ),
            RewardTask(
                id = "task_spin",
                title = "Lucky Wheel Spin",
                titleHi = "लकी व्हील स्पिन",
                description = "Spin the wheel to win up to 100 coins",
                descriptionHi = "पहिया घुमाएँ और 100 तक सिक्के जीतें",
                rewardCoins = 50,
                type = TaskType.SPIN_WHEEL,
                iconName = "motion_photos_on",
                maxTimesPerDay = 5
            ),
            RewardTask(
                id = "task_scratch",
                title = "Lucky Scratch Card",
                titleHi = "लकी स्क्रैच कार्ड",
                description = "Scratch the secret card to reveal surprise reward",
                descriptionHi = "कार्ड खुरचें और सरप्राइज कॉइन्स पाएँ",
                rewardCoins = 40,
                type = TaskType.SCRATCH_CARD,
                iconName = "crop_portrait",
                maxTimesPerDay = 5
            ),
            RewardTask(
                id = "task_quiz",
                title = "Speed Math & GK Quiz",
                titleHi = "स्पीड गणित और सामान्य ज्ञान क्विज",
                description = "Answer simple daily questions correctly",
                descriptionHi = "सरल प्रश्नों का सही उत्तर देकर सिक्के जीतें",
                rewardCoins = 35,
                type = TaskType.MATH_QUIZ,
                iconName = "quiz",
                maxTimesPerDay = 3
            ),
            RewardTask(
                id = "task_telegram",
                title = "Join Official Telegram Channel",
                titleHi = "टेलीग्राम चैनल से जुड़ें",
                description = "Get daily giveaway codes and withdrawal updates",
                descriptionHi = "गिवअवे कोड्स और ताज़ा अपडेट्स पाएँ",
                rewardCoins = 50,
                type = TaskType.SOCIAL,
                iconName = "send",
                maxTimesPerDay = 1
            ),
            RewardTask(
                id = "task_youtube",
                title = "Subscribe Daily Rewards Channel",
                titleHi = "यूट्यूब चैनल सब्सक्राइब करें",
                description = "Watch reward proof videos and guides",
                descriptionHi = "पेमेंट प्रूफ और गाइड वीडियो देखें",
                rewardCoins = 50,
                type = TaskType.SOCIAL,
                iconName = "smart_display",
                maxTimesPerDay = 1
            ),
            RewardTask(
                id = "task_survey",
                title = "Daily Opinion Survey",
                titleHi = "दैनिक ओपिनियन सर्वे",
                description = "Share your quick feedback about Indian shopping",
                descriptionHi = "शॉपिंग से जुड़े 2 सवालों के जवाब दें",
                rewardCoins = 100,
                type = TaskType.SURVEY,
                iconName = "rate_review",
                maxTimesPerDay = 1
            )
        )
        _tasks.value = defaultTasks
    }

    private fun loadTransactions() {
        val list = mutableListOf<CoinTransaction>()
        list.add(
            CoinTransaction(
                id = "tx_welcome",
                title = "Welcome Bonus",
                titleHi = "स्वागत बोनस",
                description = "Account creation reward",
                amount = 100,
                type = TransactionType.EARNED,
                timestamp = System.currentTimeMillis() - 86400000L * 2
            )
        )
        list.add(
            CoinTransaction(
                id = "tx_streak_1",
                title = "Day 1 Streak Bonus",
                titleHi = "दिन 1 हाजिरी बोनस",
                description = "Daily check-in reward",
                amount = 10,
                type = TransactionType.EARNED,
                timestamp = System.currentTimeMillis() - 86400000L * 2
            )
        )
        list.add(
            CoinTransaction(
                id = "tx_streak_2",
                title = "Day 2 Streak Bonus",
                titleHi = "दिन 2 हाजिरी बोनस",
                description = "Daily check-in reward",
                amount = 20,
                type = TransactionType.EARNED,
                timestamp = System.currentTimeMillis() - 86400000L
            )
        )
        list.add(
            CoinTransaction(
                id = "tx_referral_sample",
                title = "Referral Bonus",
                titleHi = "रेफरल बोनस",
                description = "Friend joined with code REWARD77K",
                amount = 250,
                type = TransactionType.EARNED,
                timestamp = System.currentTimeMillis() - 43200000L
            )
        )
        _transactions.value = list
    }

    private fun loadWithdrawals() {
        val list = mutableListOf<WithdrawalRequest>()
        // Sample previous withdrawal for user confidence
        list.add(
            WithdrawalRequest(
                id = "wdr_101",
                userId = "usr_rohit_01",
                userName = "Rohit Kumar",
                method = PayoutMethod.UPI,
                payoutDetails = "rohit62175@okaxis",
                coinsAmount = 500,
                inrAmount = 50.0,
                status = WithdrawalStatus.APPROVED,
                requestTimestamp = System.currentTimeMillis() - 172800000L,
                processedTimestamp = System.currentTimeMillis() - 150000000L,
                adminNote = "Payout processed via Axis Bank UPI",
                utrOrRefNumber = "UPI/329871298412"
            )
        )
        _withdrawals.value = list
    }

    // ---------------- AUTHENTICATION ----------------
    fun loginWithEmail(email: String, pass: String): Result<User> {
        if (email.isBlank() || pass.isBlank()) {
            return Result.failure(Exception("Please enter valid email and password"))
        }
        val user = _currentUser.value?.copy(email = email) ?: User(
            id = "usr_" + UUID.randomUUID().toString().take(8),
            name = email.substringBefore("@").replaceFirstChar { it.uppercase() },
            email = email,
            referralCode = generateReferralCode(),
            totalCoins = 100
        )
        _currentUser.value = user
        saveUser(user)
        return Result.success(user)
    }

    fun signUpWithEmail(name: String, email: String, pass: String, refCode: String?): Result<User> {
        if (name.isBlank() || email.isBlank() || pass.length < 6) {
            return Result.failure(Exception("Name and email are required. Password must be 6+ chars."))
        }
        var bonus = 100L
        var referrer: String? = null
        if (!refCode.isNullOrBlank()) {
            val trimmed = refCode.trim().uppercase()
            referrer = trimmed
            bonus += _adminConfig.value.refereeBonusCoins // Extra 100 coins for referee!
        }
        val newUser = User(
            id = "usr_" + UUID.randomUUID().toString().take(8),
            name = name.trim(),
            email = email.trim(),
            referralCode = generateReferralCode(),
            referredBy = referrer,
            totalCoins = bonus
        )
        _currentUser.value = newUser
        saveUser(newUser)

        // Add welcome transaction
        addTransaction(
            title = "Welcome Signup Bonus",
            titleHi = "स्वागत साइनअप बोनस",
            description = if (referrer != null) "Welcome bonus + Referral invite bonus" else "Account registration bonus",
            amount = bonus,
            type = TransactionType.EARNED
        )

        return Result.success(newUser)
    }

    fun loginWithGoogle(accountName: String, accountEmail: String): User {
        val user = User(
            id = "usr_g_" + UUID.randomUUID().toString().take(8),
            name = accountName,
            email = accountEmail,
            referralCode = generateReferralCode(),
            totalCoins = 150
        )
        _currentUser.value = user
        saveUser(user)
        addTransaction(
            title = "Google Sign-In Bonus",
            titleHi = "गूगल साइन-इन बोनस",
            description = "Verified Google sign-in reward",
            amount = 150,
            type = TransactionType.EARNED
        )
        return user
    }

    fun logout() {
        // Keep default or cleared state
        _currentUser.value = null
        prefs.edit().remove("current_user").apply()
    }

    fun toggleAdminMode() {
        val user = _currentUser.value ?: return
        val updated = user.copy(isAdmin = !user.isAdmin)
        _currentUser.value = updated
        saveUser(updated)
    }

    // ---------------- COIN LEDGER & TASKS ----------------
    fun claimDailyCheckIn(): Result<Long> {
        val user = _currentUser.value ?: return Result.failure(Exception("Please login first"))
        val today = getTodayDateString()
        if (user.lastCheckInDate == today) {
            return Result.failure(Exception("Already checked in today! Come back tomorrow."))
        }

        val streak = if (user.lastCheckInDate == getYesterdayDateString()) {
            (user.checkInStreak % 7) + 1
        } else {
            1
        }

        // Streak rewards scale nicely:
        // Day 1: 10, Day 2: 20, Day 3: 30, Day 4: 50, Day 5: 75, Day 6: 100, Day 7: 200 Mega Bonus!
        val rewardAmount = when (streak) {
            1 -> 10L
            2 -> 20L
            3 -> 30L
            4 -> 50L
            5 -> 75L
            6 -> 100L
            else -> 200L
        }

        val updatedUser = user.copy(
            totalCoins = user.totalCoins + rewardAmount,
            lastCheckInDate = today,
            checkInStreak = streak
        )
        _currentUser.value = updatedUser
        saveUser(updatedUser)

        addTransaction(
            title = "Day $streak Streak Reward",
            titleHi = "दिन $streak हाजिरी रिवॉर्ड",
            description = "Daily check-in consecutive streak reward",
            amount = rewardAmount,
            type = TransactionType.EARNED
        )

        // Mark task completed
        _tasks.value = _tasks.value.map {
            if (it.type == TaskType.DAILY_CHECKIN) it.copy(isCompletedToday = true) else it
        }

        return Result.success(rewardAmount)
    }

    fun completeTask(taskId: String, customCoins: Long? = null): Result<Long> {
        val user = _currentUser.value ?: return Result.failure(Exception("Please login first"))
        val task = _tasks.value.find { it.id == taskId } ?: return Result.failure(Exception("Task not found"))

        if (task.timesCompletedToday >= task.maxTimesPerDay) {
            return Result.failure(Exception("Task limit reached for today. Try again tomorrow!"))
        }

        val coinsAwarded = customCoins ?: task.rewardCoins

        val updatedUser = user.copy(totalCoins = user.totalCoins + coinsAwarded)
        _currentUser.value = updatedUser
        saveUser(updatedUser)

        addTransaction(
            title = task.title,
            titleHi = task.titleHi,
            description = "Completed task: ${task.title}",
            amount = coinsAwarded,
            type = TransactionType.EARNED
        )

        val updatedTimes = task.timesCompletedToday + 1
        _tasks.value = _tasks.value.map {
            if (it.id == taskId) {
                it.copy(
                    timesCompletedToday = updatedTimes,
                    isCompletedToday = updatedTimes >= it.maxTimesPerDay,
                    lastCompletedTime = System.currentTimeMillis()
                )
            } else it
        }

        return Result.success(coinsAwarded)
    }

    // ---------------- REFERRAL SYSTEM ----------------
    fun applyReferralCode(code: String): Result<Long> {
        val user = _currentUser.value ?: return Result.failure(Exception("Please login first"))
        val cleanCode = code.trim().uppercase()

        if (cleanCode == user.referralCode) {
            return Result.failure(Exception("You cannot use your own referral code!"))
        }
        if (user.referredBy != null) {
            return Result.failure(Exception("You have already claimed a referral bonus!"))
        }

        val bonusCoins = _adminConfig.value.refereeBonusCoins // 100 coins
        val updatedUser = user.copy(
            referredBy = cleanCode,
            totalCoins = user.totalCoins + bonusCoins
        )
        _currentUser.value = updatedUser
        saveUser(updatedUser)

        addTransaction(
            title = "Friend Invite Bonus",
            titleHi = "मित्र आमंत्रण बोनस",
            description = "Redeemed invite code $cleanCode",
            amount = bonusCoins,
            type = TransactionType.EARNED
        )

        return Result.success(bonusCoins)
    }

    fun recordSuccessfulReferral() {
        val user = _currentUser.value ?: return
        val bonus = _adminConfig.value.referralBonusCoins // 250 coins
        val updated = user.copy(
            totalCoins = user.totalCoins + bonus,
            successfulReferralsCount = user.successfulReferralsCount + 1
        )
        _currentUser.value = updated
        saveUser(updated)

        addTransaction(
            title = "Referral Reward",
            titleHi = "रेफरल रिवॉर्ड",
            description = "New friend joined using your code ${user.referralCode}",
            amount = bonus,
            type = TransactionType.EARNED
        )
    }

    // ---------------- WALLET & WITHDRAWALS ----------------
    fun requestWithdrawal(method: PayoutMethod, payoutDetails: String, coins: Long): Result<WithdrawalRequest> {
        val user = _currentUser.value ?: return Result.failure(Exception("Please login first"))
        val minThreshold = _adminConfig.value.minimumWithdrawalCoins

        if (coins < minThreshold) {
            return Result.failure(Exception("Minimum withdrawal is $minThreshold coins (₹${minThreshold / _adminConfig.value.coinsPerRupee})"))
        }
        if (user.totalCoins < coins) {
            return Result.failure(Exception("Insufficient coins balance. You have ${user.totalCoins} coins."))
        }
        if (payoutDetails.isBlank()) {
            return Result.failure(Exception("Please enter valid payout address / phone / UPI ID"))
        }

        val inrValue = coins.toDouble() / _adminConfig.value.coinsPerRupee

        // Deduct coins from user balance
        val updatedUser = user.copy(
            totalCoins = user.totalCoins - coins,
            totalWithdrawnCoins = user.totalWithdrawnCoins + coins
        )
        _currentUser.value = updatedUser
        saveUser(updatedUser)

        val request = WithdrawalRequest(
            id = "wdr_" + UUID.randomUUID().toString().take(8),
            userId = user.id,
            userName = user.name,
            method = method,
            payoutDetails = payoutDetails.trim(),
            coinsAmount = coins,
            inrAmount = inrValue,
            status = WithdrawalStatus.PENDING,
            requestTimestamp = System.currentTimeMillis()
        )

        _withdrawals.value = listOf(request) + _withdrawals.value

        addTransaction(
            title = "Withdrawal (${method.title})",
            titleHi = "पैसे निकासी (${method.title})",
            description = "₹$inrValue requested to $payoutDetails",
            amount = coins,
            type = TransactionType.WITHDRAWN,
            status = "PENDING"
        )

        return Result.success(request)
    }

    // ---------------- ADMIN ACTIONS ----------------
    fun adminApproveWithdrawal(requestId: String, utrNumber: String): Result<Unit> {
        val request = _withdrawals.value.find { it.id == requestId }
            ?: return Result.failure(Exception("Request not found"))

        val updated = request.copy(
            status = WithdrawalStatus.APPROVED,
            processedTimestamp = System.currentTimeMillis(),
            utrOrRefNumber = utrNumber.ifBlank { "UPI/TXN" + System.currentTimeMillis().toString().takeLast(8) },
            adminNote = "Approved & Transfer Confirmed"
        )

        _withdrawals.value = _withdrawals.value.map { if (it.id == requestId) updated else it }
        return Result.success(Unit)
    }

    fun adminRejectWithdrawal(requestId: String, reason: String): Result<Unit> {
        val request = _withdrawals.value.find { it.id == requestId }
            ?: return Result.failure(Exception("Request not found"))

        val updated = request.copy(
            status = WithdrawalStatus.REJECTED,
            processedTimestamp = System.currentTimeMillis(),
            adminNote = reason.ifBlank { "Invalid payout address" }
        )

        _withdrawals.value = _withdrawals.value.map { if (it.id == requestId) updated else it }

        // Refund coins back to current user if it's their request
        if (_currentUser.value?.id == request.userId) {
            val user = _currentUser.value!!
            val refunded = user.copy(
                totalCoins = user.totalCoins + request.coinsAmount,
                totalWithdrawnCoins = (user.totalWithdrawnCoins - request.coinsAmount).coerceAtLeast(0)
            )
            _currentUser.value = refunded
            saveUser(refunded)

            addTransaction(
                title = "Withdrawal Refund",
                titleHi = "निकासी रिफंड",
                description = "Coins returned: ${updated.adminNote}",
                amount = request.coinsAmount,
                type = TransactionType.EARNED
            )
        }

        return Result.success(Unit)
    }

    fun updateAdminConfig(minCoins: Long, coinsPerRupee: Long, notice: String) {
        _adminConfig.value = _adminConfig.value.copy(
            minimumWithdrawalCoins = minCoins,
            coinsPerRupee = coinsPerRupee,
            noticeBoardText = notice
        )
    }

    // ---------------- UTILS ----------------
    private fun addTransaction(
        title: String,
        titleHi: String,
        description: String,
        amount: Long,
        type: TransactionType,
        status: String = "SUCCESS"
    ) {
        val tx = CoinTransaction(
            id = "tx_" + UUID.randomUUID().toString().take(8),
            title = title,
            titleHi = titleHi,
            description = description,
            amount = amount,
            type = type,
            timestamp = System.currentTimeMillis(),
            status = status
        )
        _transactions.value = listOf(tx) + _transactions.value
    }

    private fun generateReferralCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return "REWARD" + (1..3).map { chars.random() }.joinToString("")
    }

    private fun getTodayDateString(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    private fun getYesterdayDateString(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(System.currentTimeMillis() - 86400000L))
    }

    private fun saveUser(user: User) {
        val json = JSONObject().apply {
            put("id", user.id)
            put("name", user.name)
            put("email", user.email)
            put("referralCode", user.referralCode)
            put("referredBy", user.referredBy ?: "")
            put("totalCoins", user.totalCoins)
            put("totalWithdrawnCoins", user.totalWithdrawnCoins)
            put("successfulReferralsCount", user.successfulReferralsCount)
            put("isAdmin", user.isAdmin)
            put("lastCheckInDate", user.lastCheckInDate)
            put("checkInStreak", user.checkInStreak)
        }
        prefs.edit().putString("current_user", json.toString()).apply()
    }

    private fun parseUser(jsonString: String): User {
        val obj = JSONObject(jsonString)
        return User(
            id = obj.getString("id"),
            name = obj.getString("name"),
            email = obj.getString("email"),
            referralCode = obj.optString("referralCode", "REWARD99"),
            referredBy = obj.optString("referredBy").ifBlank { null },
            totalCoins = obj.optLong("totalCoins", 100),
            totalWithdrawnCoins = obj.optLong("totalWithdrawnCoins", 0),
            successfulReferralsCount = obj.optInt("successfulReferralsCount", 0),
            isAdmin = obj.optBoolean("isAdmin", false),
            lastCheckInDate = obj.optString("lastCheckInDate", ""),
            checkInStreak = obj.optInt("checkInStreak", 0)
        )
    }
}
