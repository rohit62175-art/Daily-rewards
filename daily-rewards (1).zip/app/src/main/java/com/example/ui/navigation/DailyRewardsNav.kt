package com.example.ui.navigation

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AdminLoginDialog
import com.example.ui.components.ConfigInfoDialog
import com.example.ui.components.MathQuizDialog
import com.example.ui.components.RewardCelebrationDialog
import com.example.ui.components.ScratchCardDialog
import com.example.ui.components.SpinWheelDialog
import com.example.ui.components.WithdrawDialog
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.AuthDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ReferralScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.PrimaryGold
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextOnGold
import com.example.ui.viewmodel.DailyRewardsViewModel
import com.example.ui.viewmodel.UiEvent
import kotlinx.coroutines.flow.collectLatest

@Composable
fun DailyRewardsApp(
    viewModel: DailyRewardsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedTab by viewModel.selectedTab.collectAsState()
    val adminConfig by viewModel.adminConfig.collectAsState()
    val user by viewModel.currentUser.collectAsState()
    val lang by viewModel.language.collectAsState()

    // Dialog state collectors
    val showSpin by viewModel.showSpinDialog.collectAsState()
    val showScratch by viewModel.showScratchDialog.collectAsState()
    val showQuiz by viewModel.showQuizDialog.collectAsState()
    val showWithdraw by viewModel.showWithdrawDialog.collectAsState()
    val showAdminLogin by viewModel.showAdminLoginDialog.collectAsState()
    val showAuth by viewModel.showAuthSheet.collectAsState()
    val showConfigInfo by viewModel.showConfigInfoDialog.collectAsState()

    // Screen navigation
    var currentScreen by remember { mutableStateOf("MAIN") } // "MAIN" or "ADMIN"

    // Celebration modal state
    var celebrationCoins by remember { mutableLongStateOf(0L) }
    var celebrationTitle by remember { mutableStateOf("") }
    var showCelebration by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.eventFlow.collectLatest { event ->
            when (event) {
                is UiEvent.ShowToast -> {
                    Toast.makeText(context, event.message, Toast.LENGTH_SHORT).show()
                }
                is UiEvent.RewardCelebration -> {
                    celebrationCoins = event.coins
                    celebrationTitle = event.title
                    showCelebration = true
                }
            }
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark),
        containerColor = BackgroundDark,
        bottomBar = {
            if (currentScreen == "MAIN") {
                NavigationBar(
                    modifier = Modifier
                        .testTag("bottom_nav_bar")
                        .windowInsetsPadding(WindowInsets.navigationBars),
                    containerColor = SurfaceDark,
                    tonalElevation = 8.dp
                ) {
                    val tabs = listOf(
                        Triple("home", if (lang == "hi") "होम" else "Home", Icons.Default.Home),
                        Triple("tasks", if (lang == "hi") "टास्क" else "Tasks", Icons.Default.TaskAlt),
                        Triple("refer", if (lang == "hi") "रेफर" else "Refer", Icons.Default.Share),
                        Triple("wallet", if (lang == "hi") "वॉलेट" else "Wallet", Icons.Default.AccountBalanceWallet),
                        Triple("profile", if (lang == "hi") "प्रोफाइल" else "Profile", Icons.Default.Person)
                    )

                    tabs.forEach { (tabKey, label, icon) ->
                        val isSelected = selectedTab == tabKey
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { viewModel.selectTab(tabKey) },
                            icon = {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    modifier = Modifier.size(22.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = TextOnGold,
                                selectedTextColor = PrimaryGold,
                                unselectedIconColor = Color(0xFF64748B),
                                unselectedTextColor = Color(0xFF64748B),
                                indicatorColor = PrimaryGold
                            ),
                            modifier = Modifier.testTag("nav_tab_$tabKey")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Notice Board Banner
            if (currentScreen == "MAIN" && adminConfig.noticeBoardText.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1E1738))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Campaign,
                            contentDescription = "Notice",
                            tint = PrimaryGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = adminConfig.noticeBoardText,
                            fontSize = 11.sp,
                            color = GoldLight,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1
                        )
                    }
                }
            }

            // Main Content Screens
            if (currentScreen == "ADMIN") {
                AdminScreen(
                    viewModel = viewModel,
                    onBack = { currentScreen = "MAIN" }
                )
            } else {
                when (selectedTab) {
                    "home" -> HomeScreen(
                        viewModel = viewModel,
                        onNavigateToTasks = { viewModel.selectTab("tasks") },
                        onNavigateToWallet = { viewModel.selectTab("wallet") },
                        onNavigateToReferral = { viewModel.selectTab("refer") }
                    )
                    "tasks" -> TasksScreen(viewModel = viewModel)
                    "refer" -> ReferralScreen(viewModel = viewModel)
                    "wallet" -> WalletScreen(viewModel = viewModel)
                    "profile" -> ProfileScreen(
                        viewModel = viewModel,
                        onNavigateToAdmin = { currentScreen = "ADMIN" }
                    )
                }
            }
        }
    }

    // ---------------- ACTIVE DIALOGS ----------------
    if (showSpin) {
        SpinWheelDialog(
            onDismiss = { viewModel.showSpinDialog.value = false },
            onSpinWon = { coins ->
                viewModel.showSpinDialog.value = false
                viewModel.onSpinComplete(coins)
            }
        )
    }

    if (showScratch) {
        ScratchCardDialog(
            onDismiss = { viewModel.showScratchDialog.value = false },
            onScratchComplete = { coins ->
                viewModel.showScratchDialog.value = false
                viewModel.onScratchComplete(coins)
            }
        )
    }

    if (showQuiz) {
        MathQuizDialog(
            onDismiss = { viewModel.showQuizDialog.value = false },
            onAnswerSubmitted = { isCorrect ->
                viewModel.showQuizDialog.value = false
                viewModel.onQuizComplete(isCorrect)
            }
        )
    }

    if (showWithdraw) {
        WithdrawDialog(
            userCoins = user?.totalCoins ?: 0L,
            minCoins = adminConfig.minimumWithdrawalCoins,
            coinsPerRupee = adminConfig.coinsPerRupee,
            onDismiss = { viewModel.showWithdrawDialog.value = false },
            onSubmitWithdrawal = { method, details, coins ->
                viewModel.requestWithdrawal(method, details, coins)
            }
        )
    }

    if (showAdminLogin) {
        AdminLoginDialog(
            onDismiss = { viewModel.showAdminLoginDialog.value = false },
            onSuccess = {
                viewModel.showAdminLoginDialog.value = false
                viewModel.toggleAdminMode()
                currentScreen = "ADMIN"
            }
        )
    }

    if (showCelebration) {
        RewardCelebrationDialog(
            coins = celebrationCoins,
            title = celebrationTitle,
            onDismiss = { showCelebration = false }
        )
    }

    if (showConfigInfo) {
        ConfigInfoDialog(onDismiss = { viewModel.showConfigInfoDialog.value = false })
    }

    if (showAuth) {
        AuthDialog(viewModel = viewModel, onDismiss = { viewModel.showAuthSheet.value = false })
    }
}
