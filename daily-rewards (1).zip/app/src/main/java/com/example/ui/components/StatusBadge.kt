package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.WithdrawalStatus
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PrimaryGold

@Composable
fun StatusBadge(
    status: WithdrawalStatus,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, borderCol, text) = when (status) {
        WithdrawalStatus.PENDING -> Quadruple(
            PrimaryGold.copy(alpha = 0.15f),
            PrimaryGold,
            PrimaryGold.copy(alpha = 0.5f),
            "PENDING"
        )
        WithdrawalStatus.APPROVED -> Quadruple(
            EmeraldGreen.copy(alpha = 0.15f),
            EmeraldGreen,
            EmeraldGreen.copy(alpha = 0.5f),
            "APPROVED"
        )
        WithdrawalStatus.REJECTED -> Quadruple(
            ErrorRed.copy(alpha = 0.15f),
            ErrorRed,
            ErrorRed.copy(alpha = 0.5f),
            "REJECTED"
        )
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .border(1.dp, borderCol, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = text,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
