package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Vibrant Indian Rewards Palette
val PrimaryGold = Color(0xFFFFB800)
val PrimaryGoldVariant = Color(0xFFF59E0B)
val GoldDark = Color(0xFFD97706)
val GoldLight = Color(0xFFFDE68A)

// Emerald Prosperity Green
val EmeraldGreen = Color(0xFF10B981)
val EmeraldGreenDark = Color(0xFF059669)
val EmeraldGreenLight = Color(0xFFD1FAE5)

// Indian Saffron / Warm Coral
val SaffronOrange = Color(0xFFFF6B35)
val SaffronLight = Color(0xFFFFEDD5)

// Royal Navy / Deep Indigo
val BackgroundDark = Color(0xFF0D111F)
val SurfaceDark = Color(0xFF161C30)
val SurfaceDarkElevated = Color(0xFF1E2642)
val CardBorder = Color(0xFF2A365D)

// Accents
val ElectricPurple = Color(0xFF8B5CF6)
val ElectricBlue = Color(0xFF3B82F6)
val PaytmBlue = Color(0xFF002E6E)
val UpiGreen = Color(0xFF25D366)
val ErrorRed = Color(0xFFEF4444)

// Text Colors
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextOnGold = Color(0xFF1E1B4B)
