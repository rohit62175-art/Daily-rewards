package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RewardsDarkColorScheme = darkColorScheme(
  primary = PrimaryGold,
  onPrimary = TextOnGold,
  primaryContainer = GoldDark,
  onPrimaryContainer = Color.White,
  secondary = EmeraldGreen,
  onSecondary = Color.White,
  secondaryContainer = EmeraldGreenDark,
  onSecondaryContainer = Color.White,
  tertiary = SaffronOrange,
  onTertiary = Color.White,
  background = BackgroundDark,
  onBackground = TextPrimary,
  surface = SurfaceDark,
  onSurface = TextPrimary,
  surfaceVariant = SurfaceDarkElevated,
  onSurfaceVariant = TextSecondary,
  outline = CardBorder,
  error = ErrorRed,
  onError = Color.White
)

private val RewardsLightColorScheme = lightColorScheme(
  primary = PrimaryGoldVariant,
  onPrimary = Color.White,
  primaryContainer = GoldLight,
  onPrimaryContainer = TextOnGold,
  secondary = EmeraldGreen,
  onSecondary = Color.White,
  secondaryContainer = EmeraldGreenLight,
  onSecondaryContainer = EmeraldGreenDark,
  tertiary = SaffronOrange,
  onTertiary = Color.White,
  background = Color(0xFFF8FAFC),
  onBackground = Color(0xFF0F172A),
  surface = Color.White,
  onSurface = Color(0xFF0F172A),
  surfaceVariant = Color(0xFFF1F5F9),
  onSurfaceVariant = Color(0xFF475569),
  outline = Color(0xFFCBD5E1),
  error = ErrorRed,
  onError = Color.White
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Default to sleek premium dark theme
  dynamicColor: Boolean = false, // Keep branded golden-rewards theme consistent
  content: @Composable () -> Unit
) {
  val colorScheme = if (darkTheme) RewardsDarkColorScheme else RewardsLightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
