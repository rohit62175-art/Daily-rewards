package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CropPortrait
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MotionPhotosOn
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.RateReview
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.RewardTask
import com.example.model.TaskType
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.PrimaryGold
import com.example.ui.theme.SaffronOrange
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.theme.TextOnGold
import com.example.ui.viewmodel.DailyRewardsViewModel

@Composable
fun TasksScreen(
    viewModel: DailyRewardsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val tasks by viewModel.tasks.collectAsState()
    val lang by viewModel.language.collectAsState()

    var selectedCategory by remember { mutableStateOf("ALL") }
    val categories = listOf("ALL", "DAILY", "ADS & GAMES", "COMMUNITY")

    val filteredTasks = remember(tasks, selectedCategory) {
        when (selectedCategory) {
            "DAILY" -> tasks.filter { it.type == TaskType.DAILY_CHECKIN || it.type == TaskType.MATH_QUIZ }
            "ADS & GAMES" -> tasks.filter { it.type == TaskType.WATCH_AD || it.type == TaskType.SPIN_WHEEL || it.type == TaskType.SCRATCH_CARD }
            "COMMUNITY" -> tasks.filter { it.type == TaskType.SOCIAL || it.type == TaskType.SURVEY }
            else -> tasks
        }
    }

    LazyColumn(
        modifier = modifier
            .testTag("tasks_screen")
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (lang == "hi") "टास्क और रिवॉर्ड्स 🎯" else "Daily Tasks & Rewards 🎯",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Text(
                        text = if (lang == "hi") "कार्य पूरे करें और वास्तविक सिक्के कमाएँ" else "Complete daily activities to boost your earnings",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Category selector tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    val isSelected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (isSelected) PrimaryGold else Color(0xFF1E2642))
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = cat,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) TextOnGold else Color(0xFF94A3B8)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        items(filteredTasks) { task ->
            TaskItemCard(
                task = task,
                lang = lang,
                onTaskAction = {
                    when (task.type) {
                        TaskType.DAILY_CHECKIN -> viewModel.claimDailyCheckIn()
                        TaskType.WATCH_AD -> {
                            if (activity != null) viewModel.watchRewardedAd(activity)
                        }
                        TaskType.SPIN_WHEEL -> viewModel.showSpinDialog.value = true
                        TaskType.SCRATCH_CARD -> viewModel.showScratchDialog.value = true
                        TaskType.MATH_QUIZ -> viewModel.showQuizDialog.value = true
                        TaskType.SOCIAL -> {
                            // Open telegram or youtube link and reward
                            try {
                                val url = if (task.id == "task_telegram") "https://t.me/dailyrewards" else "https://youtube.com/@dailyrewards"
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                            viewModel.completeSocialTask(task.id)
                        }
                        TaskType.SURVEY -> {
                            viewModel.completeSocialTask(task.id)
                        }
                        TaskType.INVITE -> {}
                    }
                }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun TaskItemCard(
    task: RewardTask,
    lang: String,
    onTaskAction: () -> Unit
) {
    val isCompleted = task.isCompletedToday || (task.timesCompletedToday >= task.maxTimesPerDay)

    val icon: ImageVector = when (task.type) {
        TaskType.DAILY_CHECKIN -> Icons.Default.CalendarMonth
        TaskType.WATCH_AD -> Icons.Default.PlayCircle
        TaskType.SPIN_WHEEL -> Icons.Default.MotionPhotosOn
        TaskType.SCRATCH_CARD -> Icons.Default.CropPortrait
        TaskType.MATH_QUIZ -> Icons.Default.Quiz
        TaskType.SOCIAL -> if (task.id == "task_telegram") Icons.Default.Send else Icons.Default.SmartDisplay
        TaskType.SURVEY -> Icons.Default.RateReview
        TaskType.INVITE -> Icons.Default.Star
    }

    Card(
        modifier = Modifier
            .testTag("task_card_" + task.id)
            .fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
        border = BorderStroke(
            1.dp,
            if (isCompleted) EmeraldGreen.copy(alpha = 0.3f) else Color(0xFF283452)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isCompleted) EmeraldGreen.copy(alpha = 0.2f) else PrimaryGold.copy(alpha = 0.15f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isCompleted) EmeraldGreen else PrimaryGold,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = if (lang == "hi") task.titleHi else task.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                    Text(
                        text = if (lang == "hi") task.descriptionHi else task.description,
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8),
                        maxLines = 1
                    )
                    Row(
                        modifier = Modifier.padding(top = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "+${task.rewardCoins} Coins",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryGold
                        )
                        if (task.maxTimesPerDay > 1) {
                            Text(
                                text = " • ${task.timesCompletedToday}/${task.maxTimesPerDay} today",
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            if (isCompleted) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(EmeraldGreen.copy(alpha = 0.15f))
                        .border(1.dp, EmeraldGreen, RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = EmeraldGreen,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "DONE",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = EmeraldGreen
                        )
                    }
                }
            } else {
                Button(
                    onClick = onTaskAction,
                    modifier = Modifier
                        .testTag("action_task_" + task.id)
                        .height(38.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryGold,
                        contentColor = TextOnGold
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "Claim",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
