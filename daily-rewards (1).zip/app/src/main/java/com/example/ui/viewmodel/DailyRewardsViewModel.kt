package com.example.ui.viewmodel

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ads.AdMobRewardManager
import com.example.data.DailyRewardsRepository
import com.example.model.AdminConfig
import com.example.model.CoinTransaction
import com.example.model.PayoutMethod
import com.example.model.RewardTask
import com.example.model.TransactionType
import com.example.model.User
import com.example.model.WithdrawalRequest
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class UiEvent {
    data class ShowToast(val message: String) : UiEvent()
    data class RewardCelebration(val coins: Long, val title: String) : UiEvent()
}

class DailyRewardsViewModel(application: Application) : AndroidViewModel(application) {

    val repository = DailyRewardsRepository(application)
    val adManager = AdMobRewardManager(application)

    val currentUser: StateFlow<User?> = repository.currentUser
    val tasks: StateFlow<List<RewardTask>> = repository.tasks
    val withdrawals: StateFlow<List<WithdrawalRequest>> = repository.withdrawals
    val adminConfig: StateFlow<AdminConfig> = repository.adminConfig
    val language: StateFlow<String> = repository.language

    private val _eventFlow = MutableSharedFlow<UiEvent>()
    val eventFlow: SharedFlow<UiEvent> = _eventFlow.asSharedFlow()

    // Transaction filter
    private val _transactionFilter = MutableStateFlow<TransactionType?>(null)
    val transactionFilter: StateFlow<TransactionType?> = _transactionFilter.asStateFlow()

    val filteredTransactions: StateFlow<List<CoinTransaction>> = combine(
        repository.transactions,
        _transactionFilter
    ) { txs, filter ->
        if (filter == null) txs else txs.filter { it.type == filter }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active bottom navigation tab
    private val _selectedTab = MutableStateFlow("home")
    val selectedTab: StateFlow<String> = _selectedTab.asStateFlow()

    // Interactive Dialog States
    val showSpinDialog = MutableStateFlow(false)
    val showScratchDialog = MutableStateFlow(false)
    val showQuizDialog = MutableStateFlow(false)
    val showWithdrawDialog = MutableStateFlow(false)
    val showAdminLoginDialog = MutableStateFlow(false)
    val showAuthSheet = MutableStateFlow(false)
    val showConfigInfoDialog = MutableStateFlow(false)

    fun selectTab(tab: String) {
        _selectedTab.value = tab
    }

    fun setTransactionFilter(filter: TransactionType?) {
        _transactionFilter.value = filter
    }

    fun toggleLanguage() {
        val current = language.value
        val next = if (current == "en") "hi" else "en"
        repository.setLanguage(next)
    }

    // ---------------- DAILY CHECK-IN ----------------
    fun claimDailyCheckIn() {
        val result = repository.claimDailyCheckIn()
        result.onSuccess { coins ->
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.RewardCelebration(coins, "Daily Check-in Bonus!"))
            }
        }.onFailure { error ->
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.ShowToast(error.message ?: "Failed to claim check-in"))
            }
        }
    }

    // ---------------- REWARDED ADS ----------------
    fun watchRewardedAd(activity: Activity) {
        adManager.showRewardedAd(
            activity = activity,
            onRewardEarned = { amount, _ ->
                val earnedCoins = 30L
                val result = repository.completeTask("task_rewarded_ad", earnedCoins)
                result.onSuccess {
                    viewModelScope.launch {
                        _eventFlow.emit(UiEvent.RewardCelebration(earnedCoins, "Rewarded Video Ad Bonus!"))
                    }
                }
            },
            onAdDismissed = {
                // Ad closed
            },
            onAdUnavailable = { message ->
                viewModelScope.launch {
                    _eventFlow.emit(UiEvent.ShowToast(message))
                }
            }
        )
    }

    // ---------------- MINI-GAMES ----------------
    fun onSpinComplete(wonCoins: Long) {
        val result = repository.completeTask("task_spin", wonCoins)
        result.onSuccess {
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.RewardCelebration(wonCoins, "Lucky Wheel Winner!"))
            }
        }.onFailure { error ->
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.ShowToast(error.message ?: "Spin limit reached"))
            }
        }
    }

    fun onScratchComplete(wonCoins: Long) {
        val result = repository.completeTask("task_scratch", wonCoins)
        result.onSuccess {
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.RewardCelebration(wonCoins, "Scratch Card Reward!"))
            }
        }.onFailure { error ->
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.ShowToast(error.message ?: "Scratch limit reached"))
            }
        }
    }

    fun onQuizComplete(correct: Boolean) {
        if (correct) {
            val wonCoins = 35L
            val result = repository.completeTask("task_quiz", wonCoins)
            result.onSuccess {
                viewModelScope.launch {
                    _eventFlow.emit(UiEvent.RewardCelebration(wonCoins, "Quiz Master Reward!"))
                }
            }.onFailure { error ->
                viewModelScope.launch {
                    _eventFlow.emit(UiEvent.ShowToast(error.message ?: "Quiz error"))
                }
            }
        } else {
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.ShowToast("Incorrect answer. Better luck next time!"))
            }
        }
    }

    fun completeSocialTask(taskId: String) {
        val result = repository.completeTask(taskId)
        result.onSuccess { coins ->
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.RewardCelebration(coins, "Community Reward Claimed!"))
            }
        }.onFailure { error ->
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.ShowToast(error.message ?: "Already completed"))
            }
        }
    }

    // ---------------- REFERRAL ----------------
    fun applyReferral(code: String) {
        val result = repository.applyReferralCode(code)
        result.onSuccess { coins ->
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.RewardCelebration(coins, "Referral Code Applied!"))
            }
        }.onFailure { error ->
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.ShowToast(error.message ?: "Invalid Referral Code"))
            }
        }
    }

    // ---------------- WITHDRAWAL ----------------
    fun requestWithdrawal(method: PayoutMethod, details: String, coins: Long) {
        val result = repository.requestWithdrawal(method, details, coins)
        result.onSuccess { req ->
            showWithdrawDialog.value = false
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.ShowToast("Withdrawal request for ₹${req.inrAmount} submitted successfully!"))
            }
        }.onFailure { error ->
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.ShowToast(error.message ?: "Withdrawal failed"))
            }
        }
    }

    // ---------------- ADMIN ACTIONS ----------------
    fun verifyAdminPin(enteredPin: String): Boolean {
        return enteredPin.trim() == adminConfig.value.adminPasscode
    }

    fun toggleAdminMode() {
        repository.toggleAdminMode()
    }

    fun approveWithdrawal(requestId: String, utr: String) {
        val res = repository.adminApproveWithdrawal(requestId, utr)
        res.onSuccess {
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.ShowToast("Withdrawal approved & UTR saved!"))
            }
        }
    }

    fun rejectWithdrawal(requestId: String, reason: String) {
        val res = repository.adminRejectWithdrawal(requestId, reason)
        res.onSuccess {
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.ShowToast("Withdrawal rejected & coins refunded."))
            }
        }
    }

    fun updateAdminConfig(minCoins: Long, coinsPerRupee: Long, notice: String) {
        repository.updateAdminConfig(minCoins, coinsPerRupee, notice)
        viewModelScope.launch {
            _eventFlow.emit(UiEvent.ShowToast("Admin settings updated!"))
        }
    }

    // ---------------- AUTH ----------------
    fun login(email: String, pass: String) {
        val res = repository.loginWithEmail(email, pass)
        res.onSuccess {
            showAuthSheet.value = false
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.ShowToast("Welcome back, ${it.name}!"))
            }
        }.onFailure { error ->
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.ShowToast(error.message ?: "Login failed"))
            }
        }
    }

    fun signUp(name: String, email: String, pass: String, refCode: String?) {
        val res = repository.signUpWithEmail(name, email, pass, refCode)
        res.onSuccess {
            showAuthSheet.value = false
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.RewardCelebration(it.totalCoins, "Account Created Successfully!"))
            }
        }.onFailure { error ->
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.ShowToast(error.message ?: "Sign up failed"))
            }
        }
    }

    fun googleSignIn(name: String, email: String) {
        val user = repository.loginWithGoogle(name, email)
        showAuthSheet.value = false
        viewModelScope.launch {
            _eventFlow.emit(UiEvent.RewardCelebration(150L, "Signed in with Google!"))
        }
    }

    fun logout() {
        repository.logout()
        viewModelScope.launch {
            _eventFlow.emit(UiEvent.ShowToast("Logged out successfully"))
        }
    }
}
