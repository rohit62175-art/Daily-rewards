package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.PayoutMethod
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.PrimaryGold
import com.example.ui.theme.SaffronOrange
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.theme.TextOnGold
import kotlinx.coroutines.launch
import kotlin.random.Random

// ---------------- 1. SPIN WHEEL DIALOG ----------------
@Composable
fun SpinWheelDialog(
    onDismiss: () -> Unit,
    onSpinWon: (Long) -> Unit
) {
    val scope = rememberCoroutineScope()
    val rotation = remember { Animatable(0f) }
    var isSpinning by remember { mutableStateOf(false) }
    val sectors = remember { listOf(10L, 25L, 50L, 15L, 75L, 100L) }
    val sectorColors = listOf(
        Color(0xFFFFB800),
        Color(0xFF10B981),
        Color(0xFF8B5CF6),
        Color(0xFFFF6B35),
        Color(0xFF3B82F6),
        Color(0xFFEC4899)
    )

    Dialog(onDismissRequest = { if (!isSpinning) onDismiss() }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
            border = BorderStroke(
                2.dp,
                Brush.verticalGradient(listOf(PrimaryGold, Color(0xFF1E2642)))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Lucky Wheel Spin 🎯",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                    IconButton(onClick = onDismiss, enabled = !isSpinning) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                Text(
                    text = "Spin to win up to 100 free coins!",
                    fontSize = 13.sp,
                    color = PrimaryGold,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Wheel Container with Pointer
                Box(
                    modifier = Modifier
                        .size(240.dp)
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(
                        modifier = Modifier
                            .size(220.dp)
                            .rotate(rotation.value)
                    ) {
                        val sliceAngle = 360f / sectors.size
                        sectors.forEachIndexed { index, _ ->
                            drawArc(
                                color = sectorColors[index % sectorColors.size],
                                startAngle = index * sliceAngle,
                                sweepAngle = sliceAngle,
                                useCenter = true
                            )
                        }
                        // Center hub
                        drawCircle(color = Color(0xFF0F172A), radius = 35.dp.toPx())
                        drawCircle(color = PrimaryGold, radius = 25.dp.toPx())
                    }

                    // Top indicator arrow
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(2.dp, Color(0xFF0F172A), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("▼", color = Color.Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        if (!isSpinning) {
                            isSpinning = true
                            val targetSectorIndex = Random.nextInt(sectors.size)
                            val wonCoins = sectors[targetSectorIndex]
                            val sliceAngle = 360f / sectors.size
                            // Calculate angle to land on that sector (with 5-8 full rotations)
                            val totalTurns = Random.nextInt(5, 8) * 360f
                            val targetRotation = totalTurns + (360f - (targetSectorIndex * sliceAngle + sliceAngle / 2f))

                            scope.launch {
                                rotation.animateTo(
                                    targetValue = targetRotation,
                                    animationSpec = tween(
                                        durationMillis = 3500,
                                        easing = FastOutSlowInEasing
                                    )
                                )
                                isSpinning = false
                                onSpinWon(wonCoins)
                            }
                        }
                    },
                    enabled = !isSpinning,
                    modifier = Modifier
                        .testTag("spin_now_button")
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGold, contentColor = TextOnGold),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        text = if (isSpinning) "Spinning..." else "SPIN NOW! 🎡",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}

// ---------------- 2. SCRATCH CARD DIALOG ----------------
@Composable
fun ScratchCardDialog(
    onDismiss: () -> Unit,
    onScratchComplete: (Long) -> Unit
) {
    val surpriseCoins = remember { listOf(25L, 35L, 40L, 50L, 75L).random() }
    var isRevealed by remember { mutableStateOf(false) }
    var scratchProgress by remember { mutableIntStateOf(0) }

    Dialog(onDismissRequest = { if (!isRevealed) onDismiss() }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
            border = BorderStroke(
                2.dp,
                Brush.verticalGradient(listOf(EmeraldGreen, PrimaryGold))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Golden Scratch Card ✨",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                Text(
                    text = "Rub or tap the card below to reveal your lucky coins!",
                    fontSize = 13.sp,
                    color = PrimaryGold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Interactive Card Area
                Box(
                    modifier = Modifier
                        .size(240.dp, 160.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF281802), Color(0xFF452B04))
                            )
                        )
                        .border(2.dp, PrimaryGold, RoundedCornerShape(16.dp))
                        .pointerInput(Unit) {
                            detectDragGestures { _, _ ->
                                if (!isRevealed) {
                                    scratchProgress += 3
                                    if (scratchProgress >= 30) {
                                        isRevealed = true
                                    }
                                }
                            }
                        }
                        .clickable {
                            // Quick tap also scratches
                            if (!isRevealed) {
                                scratchProgress += 10
                                if (scratchProgress >= 30) {
                                    isRevealed = true
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    // Underneath revealed layer
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "🎉 YOU WON!",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryGold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.MonetizationOn,
                                contentDescription = null,
                                tint = PrimaryGold,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "+$surpriseCoins Coins",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        }
                    }

                    // Scratch Cover Layer
                    if (!isRevealed) {
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(
                                    Brush.linearGradient(
                                        listOf(PrimaryGold, Color(0xFFFBBF24), GoldDark)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "🪙 SCRATCH HERE 🪙",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp,
                                    color = TextOnGold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (scratchProgress > 0) "Scratching... ($scratchProgress%)" else "Tap or swipe repeatedly",
                                    fontSize = 11.sp,
                                    color = TextOnGold.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                if (isRevealed) {
                    Button(
                        onClick = { onScratchComplete(surpriseCoins) },
                        modifier = Modifier
                            .testTag("claim_scratch_button")
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldGreen,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(
                            text = "Claim $surpriseCoins Coins Now",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                } else {
                    TextButton(onClick = { isRevealed = true }) {
                        Text("Reveal Instantly", color = PrimaryGold)
                    }
                }
            }
        }
    }
}

// ---------------- 3. MATH & GK QUIZ DIALOG ----------------
@Composable
fun MathQuizDialog(
    onDismiss: () -> Unit,
    onAnswerSubmitted: (Boolean) -> Unit
) {
    val questions = remember {
        listOf(
            Triple("What is 45 + 38?", listOf("73", "83", "93", "81"), 1),
            Triple("What is 15 × 6?", listOf("80", "90", "85", "95"), 1),
            Triple("What is 120 ÷ 4?", listOf("25", "30", "35", "20"), 1),
            Triple("What is the national currency of India?", listOf("Rupee (₹)", "Dollar ($)", "Dinar", "Euro"), 0),
            Triple("What is 250 - 85?", listOf("175", "165", "155", "185"), 1)
        )
    }
    val currentQuestion = remember { questions.random() }
    var selectedOption by remember { mutableIntStateOf(-1) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
            border = BorderStroke(
                2.dp,
                Brush.verticalGradient(listOf(ElectricBlue, ElectricPurple))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Daily Speed Quiz 🧠",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                Text(
                    text = "Answer correctly to win +35 Coins instantly!",
                    fontSize = 12.sp,
                    color = PrimaryGold,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Question Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF13192B))
                        .border(1.dp, Color(0xFF283452), RoundedCornerShape(14.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        text = currentQuestion.first,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Options
                currentQuestion.second.forEachIndexed { index, option ->
                    val isSelected = selectedOption == index
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isSelected) PrimaryGold.copy(alpha = 0.2f) else Color(0xFF161C30)
                            )
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) PrimaryGold else Color(0xFF2A365D),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { selectedOption = index }
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${('A' + index)}. ",
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) PrimaryGold else Color(0xFF94A3B8)
                            )
                            Text(
                                text = option,
                                fontSize = 15.sp,
                                color = Color.White,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = {
                        val isCorrect = selectedOption == currentQuestion.third
                        onAnswerSubmitted(isCorrect)
                    },
                    enabled = selectedOption != -1,
                    modifier = Modifier
                        .testTag("submit_quiz_button")
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryGold,
                        contentColor = TextOnGold
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("Submit Answer", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }
    }
}

// ---------------- 4. WITHDRAWAL REQUEST DIALOG ----------------
@Composable
fun WithdrawDialog(
    userCoins: Long,
    minCoins: Long,
    coinsPerRupee: Long,
    onDismiss: () -> Unit,
    onSubmitWithdrawal: (PayoutMethod, String, Long) -> Unit
) {
    var selectedMethod by remember { mutableStateOf(PayoutMethod.UPI) }
    var selectedAmountRupees by remember { mutableLongStateOf(50L) }
    var payoutDetails by remember { mutableStateOf("") }
    var inputError by remember { mutableStateOf<String?>(null) }

    val requiredCoins = selectedAmountRupees * coinsPerRupee
    val hasEnoughCoins = userCoins >= requiredCoins

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
            border = BorderStroke(
                1.5.dp,
                Brush.verticalGradient(listOf(PrimaryGold, Color(0xFF2A365D)))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Redeem Rewards 💸",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White
                        )
                        Text(
                            text = "Balance: $userCoins Coins (₹${userCoins / coinsPerRupee})",
                            fontSize = 12.sp,
                            color = PrimaryGold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Payment Methods Row
                Text(
                    text = "Select Payment Option:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFCBD5E1)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PayoutMethod.values().forEach { method ->
                        val isSelected = selectedMethod == method
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (isSelected) PrimaryGold.copy(alpha = 0.2f) else Color(0xFF13192B)
                                )
                                .border(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) PrimaryGold else Color(0xFF283452),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable { selectedMethod = method }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = method.name.replace("_", " "),
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) PrimaryGold else Color(0xFF94A3B8),
                                maxLines = 1
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Denominations
                Text(
                    text = "Select Amount (INR):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFCBD5E1)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(50L, 100L, 250L, 500L).forEach { amountInr ->
                        val isSelected = selectedAmountRupees == amountInr
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (isSelected) EmeraldGreen.copy(alpha = 0.2f) else Color(0xFF13192B)
                                )
                                .border(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) EmeraldGreen else Color(0xFF283452),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable { selectedAmountRupees = amountInr }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "₹$amountInr",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) EmeraldGreen else Color.White
                                )
                                Text(
                                    text = "${amountInr * coinsPerRupee}c",
                                    fontSize = 10.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Payout Details Input
                OutlinedTextField(
                    value = payoutDetails,
                    onValueChange = {
                        payoutDetails = it
                        inputError = null
                    },
                    label = { Text(selectedMethod.hint) },
                    singleLine = true,
                    isError = inputError != null,
                    modifier = Modifier
                        .testTag("payout_details_input")
                        .fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryGold,
                        unfocusedBorderColor = Color(0xFF2A365D),
                        focusedLabelColor = PrimaryGold,
                        unfocusedContainerColor = Color(0xFF13192B),
                        focusedContainerColor = Color(0xFF13192B)
                    )
                )
                if (inputError != null) {
                    Text(
                        text = inputError!!,
                        color = Color.Red,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Safety Assurance Notice
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0D1726))
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Security,
                        contentDescription = "Safe",
                        tint = EmeraldGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "100% Free: We NEVER ask users to pay any deposit or fee.",
                        fontSize = 10.sp,
                        color = Color(0xFF94A3B8)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (payoutDetails.isBlank()) {
                            inputError = "Please enter valid payment details"
                            return@Button
                        }
                        if (!hasEnoughCoins) {
                            inputError = "Insufficient coins balance"
                            return@Button
                        }
                        onSubmitWithdrawal(selectedMethod, payoutDetails, requiredCoins)
                    },
                    enabled = hasEnoughCoins,
                    modifier = Modifier
                        .testTag("submit_withdrawal_button")
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (hasEnoughCoins) PrimaryGold else Color(0xFF475569),
                        contentColor = TextOnGold
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        text = if (hasEnoughCoins) "Withdraw ₹$selectedAmountRupees ($requiredCoins Coins)" else "Need $requiredCoins Coins",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

// ---------------- 5. REWARD CELEBRATION MODAL ----------------
@Composable
fun RewardCelebrationDialog(
    coins: Long,
    title: String,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
            border = BorderStroke(
                2.dp,
                Brush.verticalGradient(listOf(PrimaryGold, SaffronOrange))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(PrimaryGold, SaffronOrange)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Celebration,
                        contentDescription = "Celebration",
                        tint = TextOnGold,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Congratulations!",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp,
                    color = Color.White
                )

                Text(
                    text = title,
                    fontSize = 13.sp,
                    color = PrimaryGold,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50.dp))
                        .background(Color(0xFF261D0C))
                        .border(1.5.dp, PrimaryGold, RoundedCornerShape(50.dp))
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Icon(
                        Icons.Default.MonetizationOn,
                        contentDescription = null,
                        tint = PrimaryGold,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "+$coins Coins Added",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldLight
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .testTag("celebration_done_button")
                        .fillMaxWidth()
                        .height(46.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryGold,
                        contentColor = TextOnGold
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Awesome! Continue", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ---------------- 6. ADMIN LOGIN DIALOG ----------------
@Composable
fun AdminLoginDialog(
    onDismiss: () -> Unit,
    onSuccess: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
            border = BorderStroke(
                1.5.dp,
                Brush.verticalGradient(listOf(ElectricPurple, PrimaryGold))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(ElectricPurple.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = ElectricPurple)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Admin Access Portal",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.White
                )

                Text(
                    text = "Enter secure Admin PIN (Default: 7788)",
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8),
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )

                OutlinedTextField(
                    value = pin,
                    onValueChange = {
                        pin = it
                        error = null
                    },
                    label = { Text("4-Digit Admin PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    isError = error != null,
                    modifier = Modifier
                        .testTag("admin_pin_input")
                        .fillMaxWidth()
                )

                if (error != null) {
                    Text(
                        text = error!!,
                        color = Color.Red,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = {
                        if (pin.trim() == "7788") {
                            onSuccess()
                        } else {
                            error = "Invalid PIN. Default passcode is 7788"
                        }
                    },
                    modifier = Modifier
                        .testTag("verify_admin_pin_button")
                        .fillMaxWidth()
                        .height(46.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricPurple,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Unlock Admin Mode", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ---------------- 7. CONFIGURATION TRANSPARENCY DIALOG ----------------
@Composable
fun ConfigInfoDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
            border = BorderStroke(
                1.5.dp,
                Brush.verticalGradient(listOf(ElectricBlue, PrimaryGold))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = ElectricBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Platform Config & Readiness",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color.White
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Status of Live Services:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryGold
                )

                Spacer(modifier = Modifier.height(8.dp))

                ConfigRowItem(
                    title = "Google AdMob Rewarded Ads",
                    detail = "Ready (Using Official Google Test Unit ID ca-app-pub-3940256099942544/5224354917). Replace with live ID in production.",
                    isReady = true
                )

                ConfigRowItem(
                    title = "Cloud Persistence & Auth",
                    detail = "Local persistence enabled with SharedPreferences ledger. Ready for Firebase Firestore / Google Sign-In with google-services.json.",
                    isReady = true
                )

                ConfigRowItem(
                    title = "UPI / Paytm Payouts",
                    detail = "Instant request processing & admin approval ledger with UTR reference numbers. Ready for RazorpayX / Cashfree API payout integration.",
                    isReady = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGold, contentColor = TextOnGold),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Got it", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ConfigRowItem(title: String, detail: String, isReady: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF13192B))
            .padding(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Default.CheckCircle,
                contentDescription = null,
                tint = EmeraldGreen,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
        Text(
            text = detail,
            fontSize = 11.sp,
            color = Color(0xFF94A3B8),
            modifier = Modifier.padding(top = 2.dp, start = 22.dp)
        )
    }
}
