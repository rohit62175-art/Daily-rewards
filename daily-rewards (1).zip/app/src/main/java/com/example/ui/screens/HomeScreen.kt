package com.example.ui.screens

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CropPortrait
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MotionPhotosOn
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CoinTransaction
import com.example.model.TransactionType
import com.example.ui.components.CoinBadge
import com.example.ui.components.StreakTracker
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.PrimaryGold
import com.example.ui.theme.SaffronOrange
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.theme.TextOnGold
import com.example.ui.viewmodel.DailyRewardsViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: DailyRewardsViewModel,
    onNavigateToTasks: () -> Unit,
    onNavigateToWallet: () -> Unit,
    onNavigateToReferral: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val user by viewModel.currentUser.collectAsState()
    val adminConfig by viewModel.adminConfig.collectAsState()
    val transactions by viewModel.filteredTransactions.collectAsState()
    val lang by viewModel.language.collectAsState()

    val totalCoins = user?.totalCoins ?: 0L
    val inrValue = "%.2f".format(totalCoins.toDouble() / adminConfig.coinsPerRupee)

    LazyColumn(
        modifier = modifier
            .testTag("home_screen")
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Top App Bar Greeting
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (lang == "hi") "नमस्ते, ${user?.name ?: "दोस्त"}! 👋" else "Namaste, ${user?.name ?: "Friend"}! 👋",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Text(
                        text = if (lang == "hi") "आज के रिवॉर्ड्स कलेक्ट करें" else "Ready to collect today's coins?",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.toggleLanguage() },
                        modifier = Modifier
                            .testTag("lang_toggle_button")
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E2642))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Translate,
                            contentDescription = "Language",
                            tint = PrimaryGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = { viewModel.showConfigInfoDialog.value = true },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E2642))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Config Info",
                            tint = ElectricBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // 1. Balance Gold Card
        item {
            Card(
                modifier = Modifier
                    .testTag("balance_card")
                    .fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Color(0xFF2A1C04),
                                    Color(0xFF3F2B07),
                                    Color(0xFF18223E)
                                )
                            )
                        )
                        .border(
                            1.5.dp,
                            Brush.horizontalGradient(listOf(PrimaryGold, Color(0xFF8B5CF6))),
                            RoundedCornerShape(22.dp)
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (lang == "hi") "उपलब्ध कॉइन बैलेंस" else "TOTAL COINS BALANCE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldLight,
                                letterSpacing = 1.sp
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(EmeraldGreen.copy(alpha = 0.2f))
                                    .border(1.dp, EmeraldGreen.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "10 Coins = ₹1",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldGreen
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(Brush.radialGradient(listOf(PrimaryGold, GoldDark))),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.MonetizationOn,
                                        contentDescription = null,
                                        tint = TextOnGold,
                                        modifier = Modifier.size(30.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "%,d".format(totalCoins),
                                        fontSize = 32.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "≈ ₹$inrValue INR",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryGold
                                    )
                                }
                            }

                            Button(
                                onClick = onNavigateToWallet,
                                modifier = Modifier
                                    .testTag("redeem_now_button")
                                    .height(42.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = PrimaryGold,
                                    contentColor = TextOnGold
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (lang == "hi") "निकासी" else "Redeem",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. 7-Day Streak Tracker
        item {
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val isCheckedToday = user?.lastCheckInDate == todayStr

            StreakTracker(
                streakDays = user?.checkInStreak ?: 0,
                isCheckedInToday = isCheckedToday,
                onClaimClick = { viewModel.claimDailyCheckIn() }
            )
        }

        // 3. Quick Daily Actions Grid
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (lang == "hi") "क्विक अर्निंग एक्टिविटीज" else "Quick Earning Tasks ⚡",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color.White
                    )
                    Text(
                        text = if (lang == "hi") "सभी देखें →" else "See All →",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryGold,
                        modifier = Modifier.clickable { onNavigateToTasks() }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionCard(
                        title = "Spin Wheel",
                        reward = "+Up to 100",
                        icon = Icons.Default.MotionPhotosOn,
                        gradient = listOf(PrimaryGold, Color(0xFFD97706)),
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.showSpinDialog.value = true }
                    )
                    QuickActionCard(
                        title = "Scratch Card",
                        reward = "+Up to 75",
                        icon = Icons.Default.CropPortrait,
                        gradient = listOf(EmeraldGreen, Color(0xFF059669)),
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.showScratchDialog.value = true }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionCard(
                        title = "Rewarded Ad",
                        reward = "+30 Coins",
                        icon = Icons.Default.PlayCircle,
                        gradient = listOf(SaffronOrange, Color(0xFFEA580C)),
                        modifier = Modifier.weight(1f),
                        onClick = {
                            if (activity != null) {
                                viewModel.watchRewardedAd(activity)
                            }
                        }
                    )
                    QuickActionCard(
                        title = "Speed Quiz",
                        reward = "+35 Coins",
                        icon = Icons.Default.Quiz,
                        gradient = listOf(ElectricPurple, Color(0xFF7C3AED)),
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.showQuizDialog.value = true }
                    )
                }
            }
        }

        // 4. Referral Section Banner
        item {
            Card(
                modifier = Modifier
                    .testTag("referral_banner_card")
                    .fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
                border = BorderStroke(
                    1.dp,
                    Brush.horizontalGradient(listOf(Color(0xFF8B5CF6), Color(0xFFEC4899)))
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (lang == "hi") "दोस्तों को आमंत्रित करें 🎁" else "Invite & Earn ₹25 / Friend 🎁",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                            Text(
                                text = "Get 250 coins for every friend who joins!",
                                fontSize = 12.sp,
                                color = Color(0xFFCBD5E1)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF13192B))
                            .border(1.dp, Color(0xFF283452), RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "YOUR REFERRAL CODE",
                                fontSize = 9.sp,
                                color = Color(0xFF94A3B8),
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = user?.referralCode ?: "REWARD77K",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = PrimaryGold
                            )
                        }

                        Row {
                            IconButton(
                                onClick = {
                                    val code = user?.referralCode ?: "REWARD77K"
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Referral Code", code))
                                    Toast.makeText(context, "Code $code copied!", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = Color.White)
                            }
                            IconButton(
                                onClick = {
                                    val code = user?.referralCode ?: "REWARD77K"
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(
                                            Intent.EXTRA_TEXT,
                                            "🎉 Join Daily Rewards app & earn real daily cash via UPI! Use my invite code: $code to get 100 FREE coins instantly: https://dailyrewards.app/join?ref=$code"
                                        )
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share Referral Code"))
                                }
                            ) {
                                Icon(Icons.Default.Share, contentDescription = "Share", tint = EmeraldGreen)
                            }
                        }
                    }
                }
            }
        }

        // 5. Recent Activity
        item {
            Text(
                text = if (lang == "hi") "हाल की गतिविधियाँ (सिक्के)" else "Recent Rewards Activity 📜",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color.White,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (transactions.isEmpty()) {
            item {
                Text(
                    text = "No transactions yet. Complete tasks above to earn coins!",
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8)
                )
            }
        } else {
            items(transactions.take(5)) { tx ->
                TransactionRowItem(tx = tx, lang = lang)
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun QuickActionCard(
    title: String,
    reward: String,
    icon: ImageVector,
    gradient: List<Color>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .testTag("action_" + title.lowercase().replace(" ", "_"))
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
        border = BorderStroke(1.dp, Color(0xFF283452))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(gradient)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color.White
                )
                Text(
                    text = reward,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = PrimaryGold
                )
            }
        }
    }
}

@Composable
fun TransactionRowItem(tx: CoinTransaction, lang: String) {
    val isEarned = tx.type == TransactionType.EARNED
    val formattedTime = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(tx.timestamp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
        border = BorderStroke(1.dp, Color(0xFF222B45))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(if (isEarned) EmeraldGreen.copy(alpha = 0.2f) else SaffronOrange.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isEarned) Icons.Default.MonetizationOn else Icons.Default.CallMade,
                        contentDescription = null,
                        tint = if (isEarned) EmeraldGreen else SaffronOrange,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = if (lang == "hi") tx.titleHi else tx.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color.White
                    )
                    Text(
                        text = formattedTime,
                        fontSize = 10.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            Text(
                text = "${if (isEarned) "+" else "-"}${tx.amount}",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = if (isEarned) EmeraldGreen else SaffronOrange
            )
        }
    }
}
