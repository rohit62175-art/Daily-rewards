package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.WithdrawalRequest
import com.example.model.WithdrawalStatus
import com.example.ui.components.StatusBadge
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PrimaryGold
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.theme.TextOnGold
import com.example.ui.viewmodel.DailyRewardsViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminScreen(
    viewModel: DailyRewardsViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val adminConfig by viewModel.adminConfig.collectAsState()
    val withdrawals by viewModel.withdrawals.collectAsState()

    var minWithdrawalInput by remember(adminConfig) {
        mutableStateOf(adminConfig.minimumWithdrawalCoins.toString())
    }
    var coinsPerRupeeInput by remember(adminConfig) {
        mutableStateOf(adminConfig.coinsPerRupee.toString())
    }
    var noticeInput by remember(adminConfig) {
        mutableStateOf(adminConfig.noticeBoardText)
    }

    // Modal state for approving/rejecting
    var selectedWithdrawalForAction by remember { mutableStateOf<WithdrawalRequest?>(null) }
    var actionType by remember { mutableStateOf<String?>(null) } // "APPROVE" or "REJECT"
    var actionParamInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .testTag("admin_screen")
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1E2642))
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = ElectricPurple)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Admin Control Portal",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }
                    Text(
                        text = "Manage withdrawals, tasks & reward parameters",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }
        }

        // Overview metrics
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AdminMetricCard(
                    title = "Total Payouts",
                    value = "${withdrawals.size}",
                    color = PrimaryGold,
                    modifier = Modifier.weight(1f)
                )
                AdminMetricCard(
                    title = "Pending",
                    value = "${withdrawals.count { it.status == WithdrawalStatus.PENDING }}",
                    color = Color(0xFFF59E0B),
                    modifier = Modifier.weight(1f)
                )
                AdminMetricCard(
                    title = "Approved",
                    value = "${withdrawals.count { it.status == WithdrawalStatus.APPROVED }}",
                    color = EmeraldGreen,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Payout Review Queue
        item {
            Text(
                text = "Payout Requests Queue 📋",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color.White
            )
        }

        if (withdrawals.isEmpty()) {
            item {
                Text(
                    text = "No withdrawal requests found.",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp
                )
            }
        } else {
            items(withdrawals) { req ->
                AdminWithdrawalRow(
                    request = req,
                    onApprove = {
                        selectedWithdrawalForAction = req
                        actionType = "APPROVE"
                        actionParamInput = "UPI/TXN" + System.currentTimeMillis().toString().takeLast(6)
                    },
                    onReject = {
                        selectedWithdrawalForAction = req
                        actionType = "REJECT"
                        actionParamInput = "Invalid UPI address or suspicious activity"
                    }
                )
            }
        }

        // Payout Action Prompt Card (if triggered)
        if (selectedWithdrawalForAction != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1738)),
                    border = BorderStroke(
                        1.5.dp,
                        if (actionType == "APPROVE") EmeraldGreen else ErrorRed
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (actionType == "APPROVE") "Confirm Approval for ₹${selectedWithdrawalForAction!!.inrAmount}" else "Reject & Refund Request",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.White
                        )
                        Text(
                            text = if (actionType == "APPROVE") "Enter UTR / Bank Reference number to provide proof to user:" else "Reason for rejection (refunds coins back to user):",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8),
                            modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
                        )

                        OutlinedTextField(
                            value = actionParamInput,
                            onValueChange = { actionParamInput = it },
                            singleLine = true,
                            modifier = Modifier
                                .testTag("admin_action_param_input")
                                .fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = {
                                    if (actionType == "APPROVE") {
                                        viewModel.approveWithdrawal(selectedWithdrawalForAction!!.id, actionParamInput)
                                    } else {
                                        viewModel.rejectWithdrawal(selectedWithdrawalForAction!!.id, actionParamInput)
                                    }
                                    selectedWithdrawalForAction = null
                                },
                                modifier = Modifier
                                    .testTag("admin_confirm_action_button")
                                    .weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (actionType == "APPROVE") EmeraldGreen else ErrorRed
                                )
                            ) {
                                Text("Confirm " + (if (actionType == "APPROVE") "Approval" else "Rejection"), fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { selectedWithdrawalForAction = null },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF283452))
                            ) {
                                Text("Cancel")
                            }
                        }
                    }
                }
            }
        }

        // Global Configuration Editor
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
                border = BorderStroke(1.dp, Color(0xFF283452))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Global App Parameters ⚙️",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = minWithdrawalInput,
                        onValueChange = { minWithdrawalInput = it },
                        label = { Text("Minimum Withdrawal Coins (e.g. 500 = ₹50)") },
                        singleLine = true,
                        modifier = Modifier
                            .testTag("admin_min_withdrawal_input")
                            .fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = coinsPerRupeeInput,
                        onValueChange = { coinsPerRupeeInput = it },
                        label = { Text("Coins per INR Rupee (e.g. 10 coins = ₹1)") },
                        singleLine = true,
                        modifier = Modifier
                            .testTag("admin_coins_per_rupee_input")
                            .fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = noticeInput,
                        onValueChange = { noticeInput = it },
                        label = { Text("App Notice Board Message") },
                        modifier = Modifier
                            .testTag("admin_notice_input")
                            .fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            val minC = minWithdrawalInput.toLongOrNull() ?: 500L
                            val cpr = coinsPerRupeeInput.toLongOrNull() ?: 10L
                            viewModel.updateAdminConfig(minC, cpr, noticeInput)
                        },
                        modifier = Modifier
                            .testTag("save_admin_config_button")
                            .fillMaxWidth()
                            .height(46.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElectricPurple,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save System Settings", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun AdminWithdrawalRow(
    request: WithdrawalRequest,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    val dateStr = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(request.requestTimestamp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
        border = BorderStroke(1.dp, Color(0xFF283452))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "${request.userName} • ₹${request.inrAmount.toInt()}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                    Text(
                        text = "${request.method.title}: ${request.payoutDetails}",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
                StatusBadge(status = request.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "$dateStr (${request.coinsAmount} coins)", fontSize = 10.sp, color = Color(0xFF64748B))

                if (request.status == WithdrawalStatus.PENDING) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = onApprove,
                            modifier = Modifier
                                .testTag("admin_approve_" + request.id)
                                .height(32.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Approve", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onReject,
                            modifier = Modifier
                                .testTag("admin_reject_" + request.id)
                                .height(32.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reject", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminMetricCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
        border = BorderStroke(1.dp, Color(0xFF283452))
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = color)
            Text(text = title, fontSize = 10.sp, color = Color(0xFF94A3B8))
        }
    }
}
