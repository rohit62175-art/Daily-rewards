package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AdMobRewardManager(private val context: Context) {

    companion object {
        private const val TAG = "AdMobRewardManager"
        // Official Google AdMob Test Rewarded Ad Unit ID
        const val TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
    }

    private var rewardedAd: RewardedAd? = null

    private val _isAdLoaded = MutableStateFlow(false)
    val isAdLoaded: StateFlow<Boolean> = _isAdLoaded.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _statusMessage = MutableStateFlow("Initializing Google AdMob...")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    init {
        try {
            MobileAds.initialize(context) { status ->
                Log.d(TAG, "MobileAds initialized: $status")
                _statusMessage.value = "AdMob Initialized (Using Test Unit ID)"
                loadRewardedAd()
            }
        } catch (e: Exception) {
            Log.e(TAG, "MobileAds init exception", e)
            _statusMessage.value = "AdMob local test mode"
        }
    }

    fun loadRewardedAd(onLoaded: (() -> Unit)? = null, onFailed: ((String) -> Unit)? = null) {
        if (_isLoading.value) return
        _isLoading.value = true
        _statusMessage.value = "Loading test rewarded ad..."

        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            TEST_REWARDED_AD_UNIT_ID,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    Log.w(TAG, "RewardedAd failed to load: ${loadAdError.message}")
                    rewardedAd = null
                    _isLoading.value = false
                    _isAdLoaded.value = false
                    _statusMessage.value = "Ad ready in test mode"
                    onFailed?.invoke(loadAdError.message)
                }

                override fun onAdLoaded(ad: RewardedAd) {
                    Log.d(TAG, "RewardedAd successfully loaded")
                    rewardedAd = ad
                    _isLoading.value = false
                    _isAdLoaded.value = true
                    _statusMessage.value = "Rewarded Ad Ready!"
                    onLoaded?.invoke()
                }
            }
        )
    }

    fun showRewardedAd(
        activity: Activity,
        onRewardEarned: (amount: Int, type: String) -> Unit,
        onAdDismissed: () -> Unit,
        onAdUnavailable: (String) -> Unit
    ) {
        val currentAd = rewardedAd
        if (currentAd != null) {
            currentAd.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d(TAG, "Rewarded ad dismissed")
                    rewardedAd = null
                    _isAdLoaded.value = false
                    loadRewardedAd()
                    onAdDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    Log.e(TAG, "Ad failed to show: ${adError.message}")
                    rewardedAd = null
                    _isAdLoaded.value = false
                    loadRewardedAd()
                    onAdUnavailable("Failed to display ad: ${adError.message}")
                }

                override fun onAdShowedFullScreenContent() {
                    Log.d(TAG, "Ad showed full screen")
                }
            }

            currentAd.show(activity) { rewardItem ->
                // Verified reward callback from AdMob
                Log.d(TAG, "User earned verified reward: ${rewardItem.amount} ${rewardItem.type}")
                onRewardEarned(rewardItem.amount, rewardItem.type)
            }
        } else {
            // Not ready yet, try loading again
            loadRewardedAd()
            onAdUnavailable("Rewarded Ad is preparing. Please try again in a moment!")
        }
    }
}
